package pt.iade.ricardodiasjoaocoelho.projetosolar.views;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import pt.iade.ricardodiasjoaocoelho.projetosolar.R;

public class Event_Page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.event_page_activity);


        setContentView(R.layout.activity_island_desk_reserve_page);
    }
}