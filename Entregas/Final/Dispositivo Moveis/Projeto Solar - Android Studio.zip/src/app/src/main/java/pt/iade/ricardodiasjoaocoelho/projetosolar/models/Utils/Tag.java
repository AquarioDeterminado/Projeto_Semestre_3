package pt.iade.ricardodiasjoaocoelho.projetosolar.models.Utils;

public class Tag {
    private String id;
    private String descrip;

    public Tag(String descrip)
    {
        this.descrip = descrip;
    }

    public String getDescrip()
    {
        return descrip;
    }
}
